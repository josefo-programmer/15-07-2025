package com.logicap.ai;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@RestController
public class ChatController {

    @Value("${openrouter.api.key}")
    private String apiKey;

    private List<Map<String, Object>> conversation = new ArrayList<>();

    @PostMapping("/api/chat")
    public String chat(@RequestBody Map<String, String> payload) {
        String userMessage = payload.get("message");
        if (userMessage == null || userMessage.trim().isEmpty()) {
            return "Mensaje vacío.";
        }

        // Agregar mensaje del usuario a la conversación
        conversation.add(Map.of("role", "user", "content", userMessage));

        String response = getOpenRouterResponse();

        // Agregar respuesta del asistente si hubo una
        if (response != null && !response.isEmpty()) {
            conversation.add(Map.of("role", "assistant", "content", response));
            return response;
        } else {
            //return "❌ Error al comunicarse con la IA. Revisa tu consola para más detalles.";
            return "🧪 Este mensaje prueba que el código fue actualizado.";

        }
    }

    private String getOpenRouterResponse() {
        String url = "https://openrouter.ai/api/v1/chat/completions";

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", "openai/gpt-3.5-turbo");
        requestBody.put("messages", conversation);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + apiKey);
        // headers.set("HTTP-Referer", "http://localhost:8081"); // Desactivado para entorno local
        headers.set("X-Title", "LOGICAP");

        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

        try {
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<Map> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    requestEntity,
                    Map.class
            );

            Map<String, Object> body = response.getBody();
            if (body != null && body.containsKey("choices")) {
                List<Map<String, Object>> choices = (List<Map<String, Object>>) body.get("choices");
                if (!choices.isEmpty()) {
                    Map<String, Object> message = (Map<String, Object>) choices.get(0).get("message");
                    return message.get("content").toString();
                }
            }

            return "⚠️ La respuesta de la IA no se pudo interpretar.";

        } catch (Exception e) {
            e.printStackTrace(); // Imprimir error en consola
            return "❌ Excepción al conectar con OpenRouter: " + e.getMessage();
        }
    }
}

